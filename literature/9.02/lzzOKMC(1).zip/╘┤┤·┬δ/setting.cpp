#include"setting.h"


// �����ļ���������read_setting����������setting_map������setting_map��ʼ���õ�һ��setting����
Setting::Setting(std::string filename)
{
	read_setting(filename);
	temperature = setting_map["temperature"];
	box_min.at(0) = int(setting_map["x_min"]);
	box_min.at(1) = int(setting_map["y_min"]);
	box_min.at(2) = int(setting_map["z_min"]);
	box_max.at(0) = int(setting_map["x_max"]);
	box_max.at(1) = int(setting_map["y_max"]);
	box_max.at(2) = int(setting_map["z_max"]);
	for (int i = 0; i < 3; i++) { box_length[i] = box_max.at(i) - box_min.at(i); }
	max_step = (unsigned long long)setting_map["max_step"];
	max_time = setting_map["max_time"];
	a0 = setting_map["a0"];
	kb = setting_map["kb"];
	hp = setting_map["hp"];
	stop_criteria = int(setting_map["stop_criteria"]);
	boundary_condition = int(setting_map["boundary_condition"]);
	output_c_a_e_react = setting_map["output_c_a_e_react"];
	total_output = int(setting_map["total_output"]);
	n_output = 1;
	fia_site = int(setting_map["fia_site"]);
	cascade_interval = setting_map["cascade_interval"];
	rand_translate_cascade = (int)setting_map["rand_translate_cascade"];
	mig_degeneration = (int)setting_map["mig_degeneration"];
	max_energy = setting_map["max_energy"];
	grain_radius = setting_map["grain_radius"];
	grain_radius_square = pow(grain_radius, 2);
	default_dt = setting_map["default_dt"];
	ss_grain_radius = setting_map["ss_grain_radius"];
//	if_trap_mutation = (int)setting_map["if_trap_mutation"];
	He_flux = setting_map["He_flux"];
	cal_sink_strength();


	//��һ�β���cascade��ʱ��
	cascade_insert_time = cascade_interval;
	//�������еİٷֱȽ���
	progress_percentage = 1;
	
	step = 0;
	time = 0.0;
	
	bcc_lattice_site = {
		0.0, 0.0, 0.0,
		0.5, 0.5, 0.5,
		1.0, 0.0, 0.0,
		0.0, 0.0, 1.0,
		0.0, 0.0, 1.0,
		1.0, 1.0, 0.0,
		1.0, 0.0, 1.0,
		0.0, 1.0, 1.0,
		1.0, 1.0, 1.0 };

	tis_site = {
		0.25, 0.50, 0.0,   0.25, 0.50, 1.0,
		0.50, 0.25, 0.0,   0.50, 0.25, 1.0,
		0.75, 0.50, 0.0,   0.75, 0.50, 1.0,
		0.50, 0.75, 0.0,   0.50, 0.75, 1.0,

		0.25, 0.0, 0.50,   0.25, 1.0, 0.50,
		0.50, 0.0, 0.25,   0.50, 1.0, 0.25,
		0.75, 0.0, 0.50,   0.75, 1.0, 0.50,
		0.50, 0.0, 0.75,   0.50, 1.0, 0.75,

		0.0, 0.50, 0.25,   1.0, 0.50, 0.25,
		0.0, 0.25, 0.50,   1.0, 0.25, 0.50,
		0.0, 0.50, 0.75,   1.0, 0.50, 0.75,
		0.0, 0.75, 0.50,   1.0, 0.75, 0.50, };


	read_cascade_possibility();
}

// �����ļ�������ȡ�ļ������зǿգ���#��ͷ���У��Ե�һ���ؼ���Ϊ�����ڶ����ؼ���Ϊֵ������setting map
void Setting::read_setting(std::string _filename)
{
	std::fstream inFile(_filename);
	if (inFile.is_open())
	{
		std::string str;
		while (std::getline(inFile, str))
		{
			if (!str.empty() && str.at(0) != '#')	//skip the empty line and the line started with '#'
			{
				std::istringstream ss(str);
				std::string temp;
				ss >> temp;
				ss >> setting_map[temp];
			}
		}
		std::cout << _filename << " is succssefully read.\n";
		inFile.close();
	}
	else {
		std::cout << "Fail to open " << _filename << std::endl;
	}
}

//��ȡcascade_possibility�ļ�����¼������cascade����Ϣ
void Setting::read_cascade_possibility()
{
	std::string str;
	std::ifstream inFile("input_cascade_possibility.txt");
	if (inFile.is_open()) {
		while (std::getline(inFile, str))
		{
			if (str.empty() || str.at(0) == '#') { continue; }	//skip the empty line and the line started with '#'
			std::istringstream ss(str);
			double e, p;
			int n;
			ss >> e >> p >> n;
			cascade_energy.push_back(e);
			cascade_possibility.push_back(p);
			cascade_number.push_back(n);
		}
		std::cout << "input_cascade_possibility.txt is successfully read\n";
		inFile.close();
	}
	else {
		std::cout << "Fail to open input_cascade_possibility.txt\n";
	}
}

void Setting::cal_sink_strength()
{
	if (ss_grain_radius > 0)
	{
		p_sia_meet_GB = 5.625 * a0 * a0 / ss_grain_radius / ss_grain_radius;
		p_vac_meet_GB = 1.8 * a0 * a0 / ss_grain_radius / ss_grain_radius;
	}
}